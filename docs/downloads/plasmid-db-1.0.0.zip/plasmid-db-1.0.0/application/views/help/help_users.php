<p><span class="glyphicon glyphicon-envelope"></span> : send an e-mail to user.</p>
<p><span class="glyphicon glyphicon-edit"></span> : edit user's credentials.</p>
<p><span class="glyphicon glyphicon-trash"></span> : remove user's account.</p>
<p>Click on the username to view details</p>
<p>Depending on your account type some options might be disabled.</p>