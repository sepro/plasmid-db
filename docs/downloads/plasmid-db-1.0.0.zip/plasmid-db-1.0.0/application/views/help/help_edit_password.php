<p>Fill in your current password, the new password and confirm the new password.</p>
<p>Click <strong><span class="glyphicon glyphicon-save"></span> Change password</strong> to change the password</p>