<p><span class="glyphicon glyphicon-edit"></span> : edit location info.</p>
<p><span class="glyphicon glyphicon-trash"></span> : remove location.</p>
<p><span class="glyphicon glyphicon-file"></span> : download pdf of the inventory.</p>
<p><strong><span class="glyphicon glyphicon-plus"></span> Add location</strong> : add a new location to the database.</p>
<p>Only admins can add/change/remove locations.</p>