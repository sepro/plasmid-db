<p>Click browse to select a file to upload. Uploads shouldn't be bigger than 2Mb and can only be image files in png, jpg or gif format.</p>
<p>An online tool to generate the vector map from the sequence is <a href="http://wishart.biology.ualberta.ca/PlasMapper/">PlasMapper</a>.</p>
<p>Click <strong><span class="glyphicon glyphicon-upload"></span> Upload vector map</strong> to upload the file.</p>