<p>Specify the location where the plasmid is stored.</p>
<p>Make sure the label entered here is the same as used on the physical flask/aliquot/...</p>
<p>Click <strong><span class="glyphicon glyphicon-plus"></span> Add location</strong> to add the plasmid's locaton to the database.</p>