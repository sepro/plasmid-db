<p>Change this user's details.</p>
<p>Click <strong><span class="glyphicon glyphicon-save"></span> Save changes</strong> to save the changes to this user to the database.</p>