<p>Enter the details for the new plasmid.</p>
<p>If this plasmid has been published, please add the PubMed ID (PMID) of the publication. Look up the article on <a href="http://www.ncbi.nlm.nih.gov/pubmed/">PubMed</a> to find the PMID.</p>
<p>Click <strong><span class="glyphicon glyphicon-save"></span> Save changes</strong> to store the changes in the database.</p>