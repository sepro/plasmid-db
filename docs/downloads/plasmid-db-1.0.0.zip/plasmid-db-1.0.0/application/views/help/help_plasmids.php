<p><span class="glyphicon glyphicon-edit"></span> : edit plasmid info.</p>
<p><span class="glyphicon glyphicon-trash"></span> : remove plasmid.</p>
<p><strong><span class="glyphicon glyphicon-plus"></span> Add plasmid</strong> : add a new plasmid to the database.</p>
<p>Click on the plasmid's name to view details.</p>
<p>Only admins and the person who added the plasmid can remove/edit them. Guests cannot add new plasmids.</p>