<?php include('header.php'); ?>

<div class="container main-content">

<h2>ERROR !</h2>
	<div class="alert alert-danger">
		<strong><?php echo $error; ?></strong>
	</div>
</div>

<?php include('footer.php'); ?>