
<div class="push"></div>
</div>
<footer>
    <div class="footer navbar-inverse">
       <div class="container">
	   <div class="row">
          <div class="col-md-4 col-sm-4">
		  <ul class="footer-list">
		  	<li><a href="<?php echo base_url(); ?>about">About</a></li>
		  	<li><a href="<?php echo base_url(); ?>acknowledgements">Acknowledgements</a></li>
			<li><a href="<?php echo base_url(); ?>publications">Publications</a></li>
		  </ul>
          </div>
          <div class="col-md-4 col-sm-4">
		  <ul class="footer-list">
		  	<li><a href="<?php echo base_url(); ?>start">Quick Start</a></li>
		  	<li><a href="<?php echo base_url(); ?>tutorial">Tutorial</a></li>
			<li><a href="<?php echo base_url(); ?>faq">FAQ</a></li>
		  </ul>
          </div>
          <div class="col-md-4 col-sm-4">
		  <ul class="footer-list">
		  	<li><a href="<?php echo base_url(); ?>contact">Contact</a></li>
			<li><a href="<?php echo base_url(); ?>legal">Legal</a></li>
		  </ul>
       </div>
	   </div>
	   <div class="row">
	   	  <div class="col-md-8 col-sm-6"></div>
		  <div class="col-md-4 col-sm-6"><p class="pull-right">&copy; <?php echo safe_mailto('proost@mpimp-golm.mpg.de', 'Sebastian Proost');?> 2014</p></div>
		 </div>
    </div>
</footer>
        <script src="<?php echo base_url(); ?>js/vendor/jquery-1.10.1.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.1.min.js"><\/script>')</script>

        <script src="<?php echo base_url(); ?>js/vendor/bootstrap.min.js"></script>

        <script src="<?php echo base_url(); ?>js/main.js"></script>
    </body>
</html>