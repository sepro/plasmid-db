<?php include(APPPATH.'views/header.php'); ?>


<div class="container main-content">
	<div class="row">
        <div class="col-lg-8">
    		<h2>Publications</h2>
			<p>Plasmid DB currently has not been published. If you need to include a citation please reference the URL to the official Plasmid DB website.</p>
		</div>
		
	</div>
</div> <!-- container -->

<?php include(APPPATH.'views/footer.php'); ?>